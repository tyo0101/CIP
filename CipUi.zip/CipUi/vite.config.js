import { defineConfig } from "vite";
import vue from "@vitejs/plugin-vue";
import path from "path";
// https://vitejs.dev/config/
export default defineConfig({
  plugins: [vue()],
  define: {
    __VUE_PROD_HYDRATION_MISMATCH_DETAILS__: false
  },
  server:{
    host:"127.0.0.1",
    port:"80"
  },
  base:"",
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "src"),
    },
  },
});
