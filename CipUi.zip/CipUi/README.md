# vue3 基本環境建置

## vue3 + vite + tailwindcss

> https://tailwindcss.com/docs/guides/vite#vue

Terminal

```
npm create vite@latest my-project -- --template vue
cd my-project

npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init -p
```

tailwind.config.cjs

```javascript
/** @type {import('tailwindcss').Config} */

module.exports = {
  content: ["./index.html", "./src/**/*.{vue,js,ts,jsx,tsx}"],

  theme: {
    extend: {},
  },

  plugins: [],
};
```

style.css

```
@tailwind base;
@tailwind components;
@tailwind utilities;
```

Terminal

```
npm run dev
```

## 【引入 VueRouter】安裝&建立頁面

Commit: 1c7b1ce7d6f3a2fe37639a4633be67c5ffb47c58

```
npm install vue-router@4
```

## 【引入 VueRouter】找不到頁面轉導 404

## 【環境變數 ENV】 增加各環境對應 ENV 檔案

> [Vite 官網 ENV 說明](https://cn.vitejs.dev/guide/env-and-mode.html#env-files)

- 建立需要的 ENV 檔案。
- 打包指定 ENV，設定在 package.json 中。

```js
  "scripts": {
    "local":"vite --mode dev",
    "dev": "vite build --mode dev",
    "uat": "vite build --mode uat",
    "prod": "vite build --mode prod",
    "preview": "vite preview"
  },
```

- 程式中取得 ENV 變數。

```js
alert(import.meta.env.VITE_API_BASE_URL);
```

## 【vite.config.js 設定】設定@為 src 路徑

END======================

## 【Axios】引入 axios & create api

```
npm i axios
```

- DEMO
  service.js
  okCommRespRule.js
  errCommRespRule.js
  index.vue

## 【引入 pinia】安裝&範例

```
npm i pinia
```

- DEMO
  src/page/StoreDemo.vue
  src/stores/user.js
  src/stores/test.js

## 【生命週期】範例

> [參考](https://book.vue.tw/CH1/1-7-lifecycle.html)

## 【組件】範例

增加一個 input 組件可使用 v-model 及 slot 範例
