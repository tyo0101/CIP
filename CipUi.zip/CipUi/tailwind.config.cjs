/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./index.html", "./src/**/*.{vue,js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        UbotBlue: "#17a2b8",
        UbotOrange: "#ee8f4f",
        demoRed: {
          0: "#dd9999",
        },
      },
    },
  },
  plugins: [],
};
