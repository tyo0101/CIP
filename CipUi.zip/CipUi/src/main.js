import { createApp } from "vue";
import "./style.css";
import router from "./router/router";
import { createPinia } from "pinia";
import PrimeVue from 'primevue/config';
import Aura from '@primeuix/themes/aura';
import App from "./App.vue";
import GlobalComponents from '@/components/GlobalComponents.vue';
const app = createApp(App);
app.use(GlobalComponents);
app.use(router);
app.use(createPinia());
app.use(PrimeVue, {
    theme: {
        preset: Aura
    }
});
app.mount("#app");