// DEMO
/**
  async function 內
  try { //isWaf
    let res = await service.get(
      "https://nnb66.ubt.ubot.com.tw/ttt/waf.html",
      { sid: "A123456789A" }
    );
    console.log("onMounted", res.data);
  } catch (error) {
    console.log("NNBY0901011", error);
  }
  
  OR

  service.post("https://nnb66.ubt.ubot.com.tw/ttt/waf.html"),
  {sid:"A123456789A"}).then(response=>{})

 * */
import axios from "axios";
import OkCommRespRule from "/src/service/respRule/interceptors/okCommRespRule";
import ErrCommRespRule from "/src/service/respRule/interceptors/errCommRespRule";
let service = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL,
  timeout: 70 * 1000,
  headers: {},
});
service.interceptors.request.use((config) => {
  return config;
});
// response 共同處理fn
service.interceptors.response.use(
  (response) => {
    // HttpCode200
    // response.config 可拿到axios()第三個參數
    const okCommRespRule = new OkCommRespRule(response);
    okCommRespRule.isWafDo().not0000();
    return okCommRespRule.response;
  },
  (error) => {
    // Http Code != 200 or Other Error 會落到這邊。
    // error.config 可拿到axios()第三個參數
    // error.message 固定會有訊息。
    // error.response 網路問題或request發不出去時不會有，連key都不會出現。
    const errCommRespRule = new ErrCommRespRule(error);
    errCommRespRule.noResp().isCdn().isApResp().isUnknownResp();
    // const rtError = respCdnRule(error);
    // return Promise.reject(rtError);
    return Promise.reject(errCommRespRule.error);
  }
);
export default service;
