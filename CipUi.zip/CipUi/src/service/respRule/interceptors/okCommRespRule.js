class OkCommRespRule {
  constructor(response) {
    this.response = response;
    this.typeofData = null;
    this.isDoFnExecuted = false; //response是否有處理過
    this.init();
  }
  init() {
    this.typeofData = (typeof this.response.data).toLowerCase();
  }
  base(isBool, doFn, dfDoFn) {
    if (this.isDoFnExecuted == false) {
      console.info("ok-base");
      const fn = doFn || dfDoFn;
      //===判斷START===
      if (isBool) {
        fn(this.response);
        this.isDoFnExecuted = true; //上處理過response判斷
      }
      //===判斷END===
    }
  }
  // response規則，新增的話_conditionBool執行一個匿名函數判斷respsonse後回傳booleen，_dfDoFn預設function
  isWafDo(doFn) {
    console.info("isWafDo");
    let _conditionBool = (() => {
      if (
        this.typeofData == "string" &&
        this.response.data.indexOf("Your support ID") != -1
      ) {
        return true;
      } else {
        return false;
      }
    })();
    const _dfDoFn = () => {
      console.log(
        "UEWF" + this.response.data.replace(/^.*(\d{19}).*$/, "$1").slice(15)
      );
    };
    this.base(_conditionBool, doFn, _dfDoFn);
    return this;
  }
  not0000(doFn) {
    console.info("not0000");
    let _conditionBool = (() => {
      if (
        this.typeofData == "object" &&
        this.response.data.ResCode.RtnCode !== "0000"
      ) {
        return true;
      } else {
        return false;
      }
    })();
    const _dfDoFn = () => {
      console.log(this.response);
      console.log(
        this.response.data.ResCode.RtnCode + this.response.data.ResCode.RtnDesc
      );
    };
    this.base(_conditionBool, doFn, _dfDoFn);
    return this;
  }
}
export default OkCommRespRule;
