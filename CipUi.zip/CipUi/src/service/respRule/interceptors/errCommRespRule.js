class ErrCommRespRule {
  constructor(error) {
    this.error = error;
    this.typeofData = null;
    this.isDoFnExecuted = false; //response是否有處理過
    this.init();
  }
  init() {
    let typeofData = typeof this.error.response?.data;
    this.typeofData = typeofData.toLowerCase();
  }
  base(isBool, doFn, dfDoFn) {
    if (this.isDoFnExecuted == false) {
      console.info("err-base");
      const fn = doFn || dfDoFn;
      //===判斷START===
      if (isBool) {
        fn(this.response);
        this.isDoFnExecuted = true; //上處理過response判斷
      }
      //===判斷END===
    }
  }
  // response規則，新增的話_conditionBool執行一個匿名函數判斷respsonse後回傳booleen，_dfDoFn預設function
  noResp(doFn) {
    console.info("noResp");
    let _conditionBool = (() => {
      if (this.error.hasOwnProperty("response") == false) {
        return true;
      } else {
        return false;
      }
    })();
    const _dfDoFn = () => {
      console.log("noResp:", this.error.message);
    };
    this.base(_conditionBool, doFn, _dfDoFn);
    return this;
  }

  isCdn(doFn) {
    console.info("isCdn");
    let _conditionBool = (() => {
      if (
        this.typeofData == "string" &&
        this.error.response.data.indexOf("Your support ID") != -1
      ) {
        return true;
      } else {
        return false;
      }
    })();
    const _dfDoFn = () => {
      console.log("CDN");
    };
    this.base(_conditionBool, doFn, _dfDoFn);
    return this;
  }
  isApResp(doFn) {
    console.info("isApResp");
    let _conditionBool = (() => {
      console.log(this.typeofData);
      if (this.typeofData == "object") {
        return true;
      } else {
        return false;
      }
    })();
    const _dfDoFn = () => {
      console.log(
        this.error.response.data.ResCode.RtnCode,
        this.error.response.data.ResCode.RtnDesc
      );
    };
    this.base(_conditionBool, doFn, _dfDoFn);
    return this;
  }
  isUnknownResp(doFn) {
    console.info("isUnknownResp");
    let _conditionBool = (() => {
      return true;
    })();
    const _dfDoFn = () => {
      console.log("ERR99:", this.error.message);
    };
    this.base(_conditionBool, doFn, _dfDoFn);
    return this;
  }
}
export default ErrCommRespRule;
