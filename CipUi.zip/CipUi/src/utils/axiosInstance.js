import axios from "axios";
import { useModalStore } from "@/stores/modalStore";
import { useMenuStore } from "@/stores/Home/menuStore";

const instance = axios.create({
  baseURL: "http://172.16.46.197/CIP/res/",
  timeout: 30000, //30秒
});
//發送請求攔截
instance.interceptors.request.use(
  (config) => {
    const menuStore = useMenuStore();
    const modalStore = useModalStore();
    const isLocalhost =
      location.hostname === "127.0.0.1" || location.hostname === "localhost";

    // 如果 header 沒設定 skipLoading，就自動開啟 Loading
    if (!config.skipLoading) {
      modalStore.openLoading("Loading...");
    }

    const token = menuStore.token || "";
    const uid = menuStore.uid || "";

    if (!config.data) config.data = {}; //確保有data物件

    //塞進請求體 Payload
    //如果外部沒設，才自動塞
    if (!("uid" in config.data)) {
      config.data.uid = uid || "";
    }
    if (!("token" in config.data)) {
      config.data.token = token || "";
    }

    //如果是在 localhost，則將硬編碼 token 添加到請求中
    if (isLocalhost) {
      config.data.token =
        "866C0CDEA246EF180617F55C5DFCAC81D311056425AC18155A767F4C69CD1E45";
    }

    return config;
  },
  (error) => {
    const modalStore = useModalStore();
    modalStore.closeLoading();
    modalStore.showAlert("請求發送失敗，請稍後再試！", "warning");
    return Promise.reject(error);
  }
);

//發送結果攔截
instance.interceptors.response.use(
  (response) => {
    const modalStore = useModalStore();
    modalStore.closeLoading();
    return response;
  },
  (error) => {
    const modalStore = useModalStore();
    modalStore.closeLoading();
    modalStore.showAlert("API 請求失敗，請稍後再試！", "warning");
    return Promise.reject(error);
  }
);

export default instance;
