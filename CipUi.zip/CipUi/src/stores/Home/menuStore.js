import { defineStore } from "pinia";
import { ref } from "vue";

export const useMenuStore = defineStore("menu", () => {
  // 選單狀態
  const menuItems = ref([]); // 存放 API 回傳的 funclist
  const uid = ref(null);
  const token = ref(null);

  // 跑馬燈狀態
  const marqueeText = ref("🚀犯罪資料提供系統");

  // 設定選單的方法
  const setMenu = (menu) => {
    const pathMapping = {
      "S001-001": "/TodoPage",
      "S002-001": "/InquiryNotePage",
      "S002-002": "/OtherInquiryPage",
      "S002-003": "/InquirySearchPage",
      "S010-005": "/PostUploadPage",
      "S010-001": "/AddUserPage",
      "S010-002": "/UserListPage",
      "S010-004": "/UserOperationRecord",
      "S010-003": "/ChangeUserPwd",
    };

    menuItems.value = menu.map((item) => ({
      name: item.sname,
      submenu: item.child
        ? item.child.map((sub) => ({
            name: sub.sname,
            path: pathMapping[sub.sid] || "/NotFound",
          }))
        : null,
    }));
  };

  // 設定用戶資料的方法
  const setUserData = (userData) => {
    uid.value = userData.uid;
    token.value = userData.token;
  };

  // 更新跑馬燈內容的方法
  const updateMarqueeText = (newText) => {
    marqueeText.value = newText;
  };

  return {
    menuItems,
    uid,
    token,
    setMenu,
    setUserData,
    marqueeText,
    updateMarqueeText,
  };
});
