// stores/counter.js
import { defineStore } from "pinia";
import { ref } from "vue";
export const useCounterStore = defineStore("counter", () => {
  const count = ref(0);
  const userInfo = ref({
    name: "ajc",
    loginFlag: false,
  });
  const increment = () => {
    count.value++;
  };
  const login = () => {
    userInfo.value.loginFlag = true;
  };
  return { count, increment, userInfo, login };
});
