// stores/counter.js
import { defineStore } from "pinia";
import { ref } from "vue";

export const useSysInfoStore = defineStore(
  "useSysInfoStore",
  () => {
    const sysInfo = ref({
      browser: "chrome",
    });
    return { sysInfo };
  }
  // {

  //   state: () => {
  //     return {
  //       count: 0,
  //       userInfo: {
  //         name: "jac",
  //         loginFlag: false,
  //       },
  //     };
  //   },
  //   actions: {
  //     increment() {
  //       this.count++;
  //     },
  //   },
  // }
);
