import { defineStore } from "pinia";

export const useModalStore = defineStore("modalStore", {
  state: () => ({
    loading: false,
    loadingText: "Loading...",
    alert: {
      isOpen: false,
      message: "",
      type: "confirm", // info / warning / confirm
    },
    confirm: {
      isOpen: false,
      message: "",
      onConfirm: null,
      onCancel: null,
    },
  }),
  actions: {
    openLoading(text = "Loading...") {
      this.loadingText = text;
      this.loading = true;
    },
    closeLoading() {
      this.loading = false;
    },
    showAlert(message = "", type = "confirm") {
      this.alert.message = message;
      this.alert.type = type;
      this.alert.isOpen = true;
    },
    closeAlert() {
      this.alert.isOpen = false;
    },
    showConfirm(message = "", onConfirm = null, onCancel = null) {
      this.confirm.message = message;
      this.confirm.onConfirm = onConfirm;
      this.confirm.onCancel = onCancel;
      this.confirm.isOpen = true;
    },
    confirmOk() {
      if (typeof this.confirm.onConfirm === "function") {
        this.confirm.onConfirm();
      }
      this.confirm.isOpen = false;
    },
    confirmCancel() {
      if (typeof this.confirm.onCancel === "function") {
        this.confirm.onCancel();
      }
      this.confirm.isOpen = false;
    },
  },
});
