<template class="container">
    <div class="max-w-4xl mx-auto">
        <form v-if="showForm" @submit.prevent="submitCheck">
            <h1 class="text-3xl font-bold text-center bg-UbotBlue p-4 text-white rounded-t-lg">
                使用者清單
            </h1>
            <div class="border px-6 py-10 bg-gray-200 bg-opacity-50">
                <div class="grid grid-cols-1 gap-5">
                    <div>
                        <div class="grid gap-x-24 gap-y-6 mx-6">
                            <!-- 分行代號 -->
                            <div class="mb-6">
                                <label class="mb-1 text-lg font-bold">分行代號　：</label>
                                <input v-model="form.query_branch" :disabled="branchDisabled"
                                    class="dark:border-gray-600 bg-transparent w-3/5 border-b-2 appearance-none focus:outline-none focus:border-blue-600 pl-4"
                                    type="text" placeholder="輸入分行代號" />
                            </div>

                            <!-- 使用者帳號 -->
                            <div class="mb-6">
                                <label class="mb-1 text-lg font-bold">使用者帳號：</label>
                                <input v-model="form.query_userid"
                                    class="dark:border-gray-600 bg-transparent w-3/5 border-b-2 appearance-none focus:outline-none focus:border-blue-600 pl-4"
                                    type="text" placeholder="預設為所有使用者" maxlength="8" />
                            </div>
                        </div>
                    </div>
                </div>
                <!-- 查詢按鈕 & 錯誤訊息 -->
                <div class="mt-4 flex justify-end">
                    <button type="submit" :disabled="isLoading"
                        class="bg-UbotBlue text-white px-6 py-2 rounded-md hover:brightness-110" :class="isLoading
                            ? 'bg-gray-600 hover:bg-gray-600 cursor-not-allowed'
                            : 'bg-UbotBlue text-white px-6 py-2 rounded-md hover:brightness-110'">
                        {{ isLoading ? "查詢中..." : "查詢" }}
                    </button>
                </div>
            </div>
            <AlertModal v-if="showAlert" :isOpen="showAlert" :type="alertType" :message="alertMessage"
                @close="showAlert = false" @confirm="showAlert = false" />
        </form>
        <TableModal v-if="!showForm" :items="userList" :columns="userColumns">
            <template #function="{ data }">
                <button @click="editUser(data)"
                    class="bg-UbotBlue text-white px-3 py-1 mx-1 rounded hover:brightness-110">
                    變更
                </button>
                <button @click="deleteUser(data)"
                    class="bg-red-500 text-white px-3 py-1 mx-1 rounded hover:brightness-110">
                    刪除
                </button>
                <button @click="processList(data)"
                    class="bg-UbotOrange text-white px-3 py-1 mx-1 rounded hover:brightness-110">
                    紀錄
                </button>
            </template>
        </TableModal>
        <!-- 編輯 -->
        <ModalComponent :show="showModal" @close="showModal = false">
            <div class="max-h-[400px] overflow-y-auto pr-2 space-y-4">
                <div v-for="EditUserData in EditUserDatas" :key="EditUserData.inputModel" class="flex flex-col p-4">
                    <label class="mb-1 text-lg font-bold">{{ EditUserData.label }}</label>
                    <input v-if="EditUserData.inputModel !== 'role' && EditUserData.inputModel !== 'job_title'"
                        v-model="editform[EditUserData.inputModel]" type="text"
                        class="dark:border-gray-600 bg-transparent w-full border-b-2 appearance-none focus:outline-none focus:border-blue-600 pl-4" />
                    <select v-if="EditUserData.inputModel === 'role' || EditUserData.inputModel === 'job_title'"
                        v-model="editform[EditUserData.inputModel]"
                        class="dark:border-gray-600 bg-transparent w-full border-b-2 appearance-none focus:outline-none focus:border-blue-600 pl-4">
                        <option disabled value="">請選擇</option>
                        <option v-for="option in
                        EditUserData.inputModel === 'role' ? roles
                        :jobTitles" 
                        :key="option.rid || option.code"
                        :value="option.rid || option.code">
                            {{ option.rname || option.name }}
                        </option>
                    </select>
                </div>
            </div>
            <button @click="submitForm"
                class="w-full bg-UbotBlue text-white py-2 rounded-md hover:brightness-110 transition">
                確認
            </button>
        </ModalComponent>
        <!-- 雙簽Alert -->
        <ModalComponent :show="showDsModal" @close="showDsModal = false">
            <h2 class="text-lg font-semibold mb-2 text-gray-700">覆核者帳號：</h2>
            <input type="text" placeholder="輸入文字..." v-model="editform.ds_userid"
                class="w-full p-2 border rounded-md mb-3" />
            <h2 class="text-lg font-semibold mb-2 text-gray-700">覆核者密碼：</h2>
            <input type="password" placeholder="輸入文字..." v-model="editform.ds_userpwd"
                class="w-full p-2 border rounded-md mb-3" />
            <button @click="dsModal === 'edit' ? submitEdit() : submitDelete()"
                class="w-full bg-UbotBlue text-white py-2 rounded-md hover:brightness-110 transition">
                確認
            </button>
        </ModalComponent>
        <!-- 使用者變更查詢 -->
        <ModalComponent :show="showProcessModal" @close="showProcessModal = false">
            <!-- 限高 + 捲軸區塊 -->
            <div class="max-h-[400px] overflow-y-auto pr-2 space-y-4">
                <div v-for="(item, index) in ProcessformList" :key="index"
                    class="bg-blue-50 border-l-4 border-blue-400 p-4 rounded-lg shadow-sm">
                    <div v-for="ProcessData in ProcessDatas" :key="ProcessData.field"
                        class="flex justify-between py-1 border-b last:border-b-0">
                        <span class="font-medium text-gray-700">{{ ProcessData.label }}</span>
                        <span class="text-gray-800">{{ item[ProcessData.field] }}</span>
                    </div>
                </div>
            </div>
            <button @click="showProcessModal = false"
                class="w-full bg-UbotBlue text-white py-2 rounded-md hover:brightness-110 transition">
                確認
            </button>
        </ModalComponent>
    </div>
</template>

<script setup>
import { reactive, ref, onMounted } from "vue";
import { useMenuStore } from "@/stores/Home/menuStore";
import { useModalStore } from "@/stores/modalStore";
import TableModal from "@/components/public/TableModal.vue"
import api from "@/utils/axiosInstance";
// 取得 menuStore
const modalStore = useModalStore();
const menuStore = useMenuStore();
const showForm = ref(true);
const branchDisabled = ref(false);//鎖定非600(資訊部)的分行別
const alertMessage = ref("");
const alertType = ref("confirm")
const showAlert = ref(false);
const showModal = ref(false);//變更
const showDsModal = ref(false);//雙簽
const showProcessModal = ref(false);//變更歷程記錄
const dsModal = ref('edit')//判斷是編輯還是刪除
const ProcessformList = ref([]);
const userList = ref([]);
const form = reactive({
    query_branch: "",
    query_userid: "",
});
//編輯功能欄位名稱
const editform = reactive({
    userid: '',
    branch: '',
    username: '',
    role: '',
    job_title: '',
    phone: '',
    pwd1: '',
    pwd2: '',
    ds_userid: "",
    ds_userpwd: "",
});
const roles = ref([]);
const jobTitles = ref([]);
//刪除功能欄位名稱
const deleteform = reactive({
    del_uid: '',
});
//變更歷程欄位名稱
const processform = reactive({
    chg_bid: '',
    chg_uid: '',
    chg_date: '',
    chg_type: '',
    chg_authStr: '',
});
// 查詢Table欄位結構定義
const userColumns = [
    { field: "branch", header: "單位代碼" },
    { field: "userid", header: "使用者代號" },
    { field: "username", header: "使用者名稱" },
    { field: "role", header: "角色" },
    { field: "job_title", header: "職稱" },
    { field: "phone", header: "聯絡方式" },
    { field: "function", header: "功能", slot: "function" },
];
// 變更使用者表單定義
const EditUserDatas = [
    { label: "單位代碼：", inputModel: "branch" },
    { label: "使用者代號：", inputModel: "userid" },
    { label: "使用者名稱：", inputModel: "username" },
    { label: "使用者角色：", inputModel: "role" },
    { label: "職稱：", inputModel: "job_title" },
    { label: "聯絡方式：", inputModel: "phone" },
    { label: "使用者密碼：", inputModel: "pwd1" },
    { label: "使用者密碼確認：", inputModel: "pwd2" },
];
//變更歷程表單定義
const ProcessDatas = [
    { label: "變更人員單位：", field: "chg_bid" },
    { label: "變更人員：", field: "chg_uid" },
    { label: "變更時間：", field: "chg_date" },
    { label: "變更類型：", field: "chg_type" },
    { label: "變更為角色：", field: "chg_authStr" },
];
//預設分行別
onMounted(() => {
    if (menuStore.uid) {
        if (menuStore.uid.slice(0, 3) === "600") {
            form.query_branch = "";
        } else {
            form.query_branch = menuStore.uid.slice(0, 3);
            branchDisabled.value = true;
        }
    }
});
//清空雙簽欄位
function clearDs() {
    editform.ds_userid = "";
    editform.ds_userpwd = "";
};
// 查詢
const submitCheck = async (showAlert = true) => {
    if (showAlert) modalStore.openLoading("查詢中.."); //loadingModal開啟
    const requestData = {
        data: {
            query_branch: form.query_branch,
            query_userid: form.query_userid,
        },
    };
    const response = await api.post("S000020004", requestData, { skipLoading: true });
    if (response.data.rc === "M0000") {
        userList.value = response.data.result;
        showForm.value = false;
        if (showAlert) modalStore.showAlert(response.data.msg, "confirm");
    } else {
        modalStore.showAlert(response.data.msg, "warning");
    }
};
//變更按鈕
const editUser = async (rowData) => {
    dsModal.value = 'edit';
    const requestData = {
        data: { edit_uid: rowData.userid },
    };
    const response = await api.post("S000020005", requestData);

    if (response.data.rc === "M0000") {
        showModal.value = true;
        const result = response.data.result;
        editform.userid = result.userid;
        editform.branch = result.branch;
        editform.username = result.username;
        editform.role = result.role.find(r => r.selected === "1")?.rid || '';
        roles.value = result.role;
        editform.job_title = result.job_title.find(j => j.selected === "1")?.code || '';
        jobTitles.value = result.job_title;
        editform.phone = result.phone;
    } else {
        modalStore.showAlert(response.data.msg, "warning");
    }
};

//確認編輯按鈕
const submitForm = () => {
    if (!editform.userid || !editform.branch || !editform.username || !editform.role) {
        alert("請完整填寫所有欄位!");
        return;
    }
    showDsModal.value = true;//雙簽alert
    showModal.value = false;//人員資料alert
};

//確認變更
const submitEdit = async () => {
    if (!editform.ds_userid || !editform.ds_userpwd) {
        alert("請輸入覆核者帳號或密碼");
        return;
    }
    const requestData = {
        data: {
            userid: editform.userid,
            branch: editform.branch,
            username: editform.username,
            ds_userid: editform.ds_userid,
            ds_userpwd: editform.ds_userpwd,
            pwd1: editform.pwd1,
            pwd2: editform.pwd2,
            role_selected: [editform.role],
            job_title:editform.job_title,
            phone:editform.phone
        }
    };
    const response = await api.post("S000020006", requestData, { skipLoading: true });
    if (response.data.rc === "M0121") {
        showModal.value = false;
        showDsModal.value = false;
        modalStore.openLoading("變更中..");
        clearDs();
        modalStore.showAlert("使用者編輯成功！", "confirm");
        await submitCheck(false);
    } else {
        modalStore.showAlert(response.data.msg, "warning");
    }
};

//刪除按鈕
const deleteUser = (rowData) => {
    showDsModal.value = true;
    showModal.value = false;
    dsModal.value = 'delete';
    deleteform.del_uid = rowData.userid
};
//刪除使用者
const submitDelete = async () => {
    if (!editform.ds_userid || !editform.ds_userpwd) {
        alert("請輸入覆核者帳號或密碼");
        return;
    }
    const requestData = {
        data: {
            del_uid: deleteform.del_uid,
            ds_userid: editform.ds_userid,
            ds_userpwd: editform.ds_userpwd,
        }
    };
    const response = await api.post("S000020007", requestData, { skipLoading: true });
    if (response.data.rc === "M0125") {
        showDsModal.value = false;
        modalStore.openLoading("刪除中.."); //loadingModal開啟
        modalStore.showAlert("使用者刪除成功！", "confirm");
        clearDs();
        await submitCheck(false);
    } else {
        clearDs();
        modalStore.showAlert(response.data.msg, "warning");
    }
};
//變更歷程
const processList = async (rowData) => {
    modalStore.openLoading("開啟中..");
    const requestData = {
        data: { queryUID: rowData.userid },
    };
    const response = await api.post("S000020008", requestData, { skipLoading: true });
    if (response.data.rc === "M0000") {        
        showProcessModal.value = true;
        ProcessformList.value = response.data.result;
    } else {
        modalStore.showAlert(response.data.msg, "warning");
    }
}
</script>
