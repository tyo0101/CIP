<template class="container">
    <div class="max-w-4xl mx-auto">
        <h1 class="text-3xl font-bold text-center bg-UbotBlue p-4 text-white rounded-t-lg">
            新增使用者
        </h1>
        <form @submit.prevent="submitCheck">
            <div class="border px-6 py-10 bg-gray-200 bg-opacity-50">
                <div class="grid grid-cols-1 gap-5">
                    <div>
                        <div class="grid grid-cols-2 gap-x-24 gap-y-6 mx-6">
                            <!-- 根據 userDatas 動態生成欄位 -->
                            <div v-for="userData in userDatas" :key="userData.inputModel" class="flex flex-col">
                                <label class="mb-1 text-lg font-bold">{{ userData.label }}</label>
                                <input
                                    v-if="userData.inputModel !== 'branch' && userData.inputModel !== 'role_selected' && userData.inputModel !== 'job_title'"
                                    v-model="form[userData.inputModel]" type="text"
                                    class="dark:border-gray-600 bg-transparent w-full border-b-2 appearance-none focus:outline-none focus:border-blue-600 pl-4" />
                                <select
                                    v-if="userData.inputModel === 'branch' || userData.inputModel === 'role_selected' || userData.inputModel === 'job_title'"
                                    v-model="form[userData.inputModel]"
                                    class="dark:border-gray-600 bg-transparent w-48 border-b-2 appearance-none focus:outline-none focus:border-blue-600 pl-4">
                                    <option value="" disabled>
                                        {{ 
                                        userData.inputModel === 'branch' ? '請選擇單位' 
                                        : userData.inputModel === 'role_selected' ? '請選擇角色'
                                    :'請選擇職稱'}}
                                    </option>
                                    <option v-for="option in
                                     userData.inputModel === 'branch' ? branches 
                                     : userData.inputModel === 'role_selected' ? roles
                                     : jobTitles"
                                        :key="option.branchid || option.rid || option.code"
                                        :value="option.branchid || option.rid || option.code"
                                        class="p-4">
                                        {{ option.branchname || option.rname || option.name}}</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mt-4 flex justify-end">
                    <button type="submit" :disabled="isLoading"
                        class="bg-UbotBlue text-white px-6 py-2 rounded-md hover:brightness-110" :class="isLoading
                            ? 'bg-gray-600 hover:bg-gray-600 cursor-not-allowed'
                            : 'bg-UbotBlue text-white px-6 py-2 rounded-md hover:brightness-110'">
                        {{ isLoading ? "處理中..." : "確認新增" }}
                    </button>
                </div>
            </div>
        </form>
        <ModalComponent :show="showModal" @close="showModal = false">
            <h2 class="text-lg font-semibold mb-2 text-gray-700">覆核者帳號：</h2>
            <input type="text" placeholder="輸入文字..." v-model="form.ds_userid"
                class="w-full p-2 border rounded-md mb-3" />
            <h2 class="text-lg font-semibold mb-2 text-gray-700">覆核者密碼：</h2>
            <input type="password" placeholder="輸入文字..." v-model="form.ds_userpwd"
                class="w-full p-2 border rounded-md mb-3" />
            <button @click="submitForm"
                class="w-full bg-UbotBlue text-white py-2 rounded-md hover:brightness-110 transition">
                確認
            </button>
        </ModalComponent>
    </div>
</template>

<script setup>
import { reactive, ref, onMounted } from 'vue';
import { useModalStore } from "@/stores/modalStore";
import api from "@/utils/axiosInstance";

// 取得 modalStore
const modalStore = useModalStore();
// 表單資料
const form = reactive({
    userid: "",
    branch: "",
    cname: "",
    ds_userid: "",
    ds_userpwd: "",
    role_selected: "",
    job_title: "",
    phone:"",
});

// 儲存 API 回傳的單位與角色
const roles = ref([]);
const branches = ref([]);
const jobTitles = ref([]);
const isLoading = ref(false);
const showModal = ref(false)
// 表單欄位結構定義
const userDatas = [
    { label: "新增使用者代號：", inputModel: "userid" },
    { label: "單位：", inputModel: "branch" },
    { label: "使用者名稱：", inputModel: "cname" },
    { label: "使用者角色：", inputModel: "role_selected" },
    { label: "聯絡方式：", inputModel: "phone" },
    { label: "職稱：", inputModel: "job_title" },
];
//預取
onMounted(async () => {
    const response = await api.post("S000020001");
    if (response.data.rc === "M0000") {
        roles.value = response.data.result.role;
        branches.value = response.data.result.branch;
        jobTitles.value = response.data.result.job_title;
    } else {
        modalStore.showAlert(response.data.msg, "warning");
    }
});
//確認新增按鈕
const submitCheck = () => {
    if (!form.userid || !form.branch || !form.cname || !form.role_selected || !form.phone || !form.job_title) {
        alert("請完整填寫所有欄位!");
        return;
    }
    showModal.value = true;
};
//新增人員
const submitForm = async () => {
    if (!form.ds_userid || !form.ds_userpwd) {
        alert("請輸入覆核者帳號或密碼");
        return;
    }
    modalStore.openLoading("新增中..");
    const requestData = {
        data: {
            userid: form.userid,
            branch: form.branch,
            cname: form.cname,
            ds_userid: form.ds_userid,
            ds_userpwd: form.ds_userpwd,
            role_selected: [form.role_selected],
            phone: form.phone,
            job_title: form.job_title,
        }
    };
    const response = await api.post("S000020002", requestData, { skipLoading: true });
    if (response.data.rc === "M0113") {
        showModal.value = false;
        modalStore.showAlert("使用者新增成功！", "confirm");
        form.userid = "";
        form.cname = "";
        form.ds_userid = "";
        form.ds_userpwd = "";
        form.phone = "";
    } else {
        modalStore.showAlert(response.data.msg, "warning");
    }
};

</script>
