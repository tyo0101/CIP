<template>
  <div
    class="max-w-4xl mx-auto flex flex-col items-center justify-center bg-gray-100 p-6"
  >
    <!-- 跑馬燈預覽 -->
    <div class="relative w-full flex justify-center py-6">
      <div
        class="relative w-[90%] max-w-4xl overflow-hidden rounded-full bg-gradient-to-r from-white to-orange-100 shadow-inner backdrop-blur-md border border-orange-200"
      >
        <!-- 柔和光暈 -->
        <div
          class="absolute inset-0 bg-gradient-to-r from-orange-300 via-orange-200 to-yellow-200 opacity-40 blur-2xl"
        ></div>
        <!-- 跑馬燈內容 -->
        <div v-if="newMarqueeText" class="marquee">
          <div class="marquee-content">
            <span class="marquee-text text-UbotOrange">
              {{ newMarqueeText }}
            </span>
          </div>
        </div>
      </div>
    </div>

    <!-- 文本輸入框 -->
    <div class="mt-6 w-full max-w-3xl">
      <label class="block text-lg font-bold text-gray-700 mb-2"
        >編輯跑馬燈內容：</label
      >
      <textarea
        v-model="newMarqueeText"
        maxlength="200"
        class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-orange-400 focus:outline-none text-gray-900"
        placeholder="輸入新的跑馬燈內容..."
      />
    </div>

    <div class="mt-6 flex space-x-4">
      <!-- 清空內容按鈕（較強烈的紅橙色） -->
      <button
        @click="clearMarqueeText"
        class="px-6 py-3 text-lg font-semibold text-white bg-gradient-to-r from-orange-600 to-orange-700 rounded-lg shadow-xl transform transition-all hover:scale-105 hover:shadow-2xl hover:from-orange-700 hover:to-orange-600 hover:ring-2 hover:ring-orange-400 hover:ring-opacity-60 active:translate-y-1 focus:outline-none"
      >
        清空內容
      </button>

      <!-- 確定更改公告按鈕（深藍漸層） -->
      <button
        @click="confirmUpdate"
        class="px-6 py-3 text-lg font-semibold text-white bg-gradient-to-r from-sky-600 to-sky-500 rounded-lg shadow-md transform transition-all hover:scale-105 hover:shadow-lg hover:from-sky-700 hover:to-sky-600 hover:ring-2 hover:ring-sky-300 hover:ring-opacity-60 active:translate-y-1 focus:outline-none"
      >
        確定更改公告
      </button>
    </div>
  </div>
</template>

<script setup>
import { reactive, ref, onMounted, computed } from "vue";
import { useModalStore } from "@/stores/modalStore";
import api from "@/utils/axiosInstance";
// 取得 menuStore
const modalStore = useModalStore();
const cuno = ref(""); //存CUNO
let newMarqueeText = ref("");

// 計算跑馬燈動畫時間（讓滾動速度與字數成比例）
const marqueeDuration = computed(() => {
  return Math.max((newMarqueeText.value.length / 5) * 1.5, 12) + "s";
});

// 根據字數計算跑馬燈內容的寬度，確保長文字不會過早循環
const marqueeWidth = computed(() => {
  return `${newMarqueeText.value.length * 2 * 10}px`;
});

const preReadPage = async () => {
  const response = await api.post("S000040001");
  if (response.data.rc == "M0000") {
    newMarqueeText.value = response.data.result[0].text;
    cuno.value = response.data.result[0].cuno;
  } else {
    modalStore.showAlert(response.data.msg, "warning");
  }
};
onMounted(preReadPage); //預取

/* 確定更改公告 */
const confirmUpdate = async () => {
  modalStore.showConfirm("確定要更新公告嗎？", async () => {
    const requestData = {
      data: [{
        cuno: cuno.value || "",
        text: newMarqueeText.value || "",
      }],
    };
    const response = await api.post("S000040002", requestData);
    if (response.data.rc == "M0000") {
      modalStore.showAlert(response.data.msg, "confirm");
    } else {
      modalStore.showAlert(response.data.msg, "warning");
    }
  });
};

/* 清空內容 */
const clearMarqueeText = () => {
  newMarqueeText.value = "";
};
</script>

<style scoped>
/* 定義跑馬燈動畫 */
@keyframes marquee {
  from {
    transform: translateX(25%);
  }
  to {
    transform: translateX(-100%);
  }
}

.marquee {
  display: flex;
  white-space: nowrap;
  overflow: hidden;
}

.marquee-content {
  display: flex;
  min-width: v-bind(marqueeWidth); /* 讓寬度隨字數與字體大小變化 */
  animation: marquee v-bind(marqueeDuration) linear infinite;
}

.marquee-text {
  font-size: 2rem; /* 調整字體大小 */
  font-weight: bold;
}
</style>
