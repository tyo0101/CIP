<template>
  <div class="max-w-4xl mx-auto">
    <form
      v-if="showForm"
      @submit.prevent="submitCheck"
      class="bg-white rounded-lg shadow overflow-hidden"
    >
      <h1 class="text-3xl font-bold text-center bg-UbotBlue text-white p-4">
        使用者操作紀錄
      </h1>

      <div class="p-8 bg-gray-100 space-y-8">
        <!-- 查詢單位 -->
        <div>
          <label class="block text-lg font-bold mb-1">查詢單位：</label>
          <input
            v-model="formData.querybid"
            type="text"
            :disabled="queryBidDisabled"
            class="w-full border-b-2 bg-transparent px-4 py-2 focus:outline-none focus:border-blue-600"
          />
        </div>

        <!-- 查詢使用者 -->
        <div>
          <label class="block text-lg font-bold mb-1">查詢使用者：</label>
          <input
            v-model="formData.queryuid"
            type="text"
            :disabled="queryUidDisabled"
            class="w-full border-b-2 bg-transparent px-4 py-2 focus:outline-none focus:border-blue-600"
          />
        </div>

        <!-- 選擇日期 -->
        <div>
          <label class="block text-lg font-bold mb-2">選擇日期：</label>
          <div class="flex gap-3 mb-4">
            <button
              type="button"
              class="px-4 py-2 rounded-lg shadow text-white bg-UbotOrange hover:brightness-110"
              @click="convertSearchDateTime(0)"
            >
              當日
            </button>
            <button
              type="button"
              class="px-4 py-2 rounded-lg shadow text-white bg-UbotBlue hover:brightness-110"
              @click="convertSearchDateTime(10)"
            >
              近10日
            </button>
            <button
              type="button"
              class="px-4 py-2 rounded-lg shadow text-white bg-red-500 hover:brightness-110"
              @click="convertSearchDateTime(30)"
            >
              近一個月
            </button>
          </div>
          <div class="flex items-center gap-3">
            <input
              type="date"
              v-model="formData.sdate"
              class="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
            <span class="text-gray-500">至</span>
            <input
              type="date"
              v-model="formData.edate"
              class="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          <p
            v-if="errors.searchDate"
            class="bg-red-100 border border-red-400 text-red-700 px-4 py-2 rounded text-sm mt-2 font-semibold"
          >
            {{ errors.searchDate }}
          </p>
        </div>

        <!-- 查詢按鈕 -->
        <div class="flex justify-end">
          <button
            type="submit"
            :disabled="isLoading"
            class="px-6 py-2 rounded-lg text-white shadow transition-all duration-200"
            :class="
              isLoading
                ? 'bg-gray-500 cursor-not-allowed'
                : 'bg-UbotBlue hover:brightness-110'
            "
          >
            {{ isLoading ? "查詢中..." : "查詢" }}
          </button>
        </div>
      </div>
    </form>

    <!-- 彈出視窗加上動畫、點背景關閉 -->
    <Transition name="fade-zoom">
      <div
        v-if="showTableModal"
        class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50"
        @click="showTableModal = false"
      >
        <div
          class="bg-white rounded-lg shadow-xl max-w-5xl w-full p-4 transform transition-all duration-300 max-h-[80vh] overflow-auto"
          @click.stop
        >
          <div class="flex justify-between items-center mb-4">
            <h2
              class="text-2xl font-bold text-UbotBlue border-b-2 border-UbotBlue pb-1"
            >
              查詢結果
            </h2>

            <button
              @click="showTableModal = false"
              class="text-gray-600 hover:text-red-500"
            >
              ✕
            </button>
          </div>
          <TableModal :items="userList" :columns="userColumns" />
        </div>
      </div>
    </Transition>
  </div>
</template>

<script setup>
import { reactive, ref, onMounted } from "vue";
import { useModalStore } from "@/stores/modalStore";
import TableModal from "@/components/public/TableModal.vue";
import api from "@/utils/axiosInstance";
// 取得 menuStore
const modalStore = useModalStore();
const queryBidDisabled = ref(false); //可否編輯單位 0否 1可
const queryUidDisabled = ref(false); //可否編輯使用者 0否 1可
const showTableModal = ref(false); //查詢結果視窗
const showForm = ref(true);
const isLoading = ref(false);

const userList = ref([]);
const errors = reactive({
  searchDate: "",
});

const formData = reactive({
  querybid: "",
  queryuid: "",
  edate: "",
  sdate: "",
});

// 查詢Table欄位結構定義
const userColumns = [
  { field: "uid", header: "使用者" },
  { field: "date", header: "時間" },
  { field: "ip", header: "IP" },
  { field: "desc", header: "操作內容" },
];

const preReadPage = async () => {
  const response = await api.post("S000030001");
  if (response.data.rc == "M0000") {
    formData.querybid = response.data.result.branchid;
    formData.queryuid = response.data.result.queryuid;
    if (response.data.result.branchidRW == "1") {
      //可否編輯單位 0否 1可
      queryBidDisabled.value = true;
    }
    if (response.data.result.queryuidRW == "1") {
      //可否編輯使用者 0否 1可
      queryUidDisabled.value = true;
    }
  } else {
    modalStore.showAlert(response.data.msg, "warning");
  }
};
onMounted(preReadPage); //預取

const convertSearchDateTime = (days) => {
  const today = new Date();
  const startDate = new Date();
  startDate.setDate(today.getDate() - days);
  formData.sdate = startDate.toISOString().split("T")[0];
  formData.edate = today.toISOString().split("T")[0];
};

// 查詢函數
const submitCheck = async () => {
  errors.searchDate =
    !formData.sdate || !formData.edate ? "請選擇完整日期範圍" : "";
  if (errors.searchDate != "") {
    return;
  }
  isLoading.value = true;
  const requestData = {
    data: {
      querybid: formData.querybid,
      queryuid: formData.queryuid,
      sdate: formData.sdate.replace(/-/g, "/"),
      edate: formData.edate.replace(/-/g, "/"),
    },
  };
  const response = await api.post("S000030002", requestData);
  if (response.data.rc == "M0000") {
    userList.value = response.data.result;
    showTableModal.value = true;
  } else {
    modalStore.showAlert(response.data.msg, "warning");
  }
  isLoading.value = false;
};
</script>

<style scoped>
.fade-zoom-enter-active,
.fade-zoom-leave-active {
  transition: all 0.3s ease;
}

.fade-zoom-enter-from {
  opacity: 0;
  transform: scale(0.9);
}

.fade-zoom-enter-to {
  opacity: 1;
  transform: scale(1);
}

.fade-zoom-leave-from {
  opacity: 1;
  transform: scale(1);
}

.fade-zoom-leave-to {
  opacity: 0;
  transform: scale(0.9);
}
</style>
