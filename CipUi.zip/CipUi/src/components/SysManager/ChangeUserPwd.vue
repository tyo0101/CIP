<template>
  <div class="max-w-4xl mx-auto">
    <form
      @submit.prevent="submitCheck"
      class="bg-white rounded-lg shadow overflow-hidden"
    >
      <h1 class="text-3xl font-bold text-center bg-UbotBlue text-white p-4">
        變更密碼
      </h1>

      <div class="p-8 bg-gray-100 space-y-8">
        <!-- 原密碼 -->
        <div>
          <label class="block text-lg font-bold mb-1">原密碼：</label>
          <input
            v-model="formData.ori_pwd"
            type="text"
            class="w-full border-b-2 bg-transparent px-4 py-2 focus:outline-none focus:border-blue-600"
          />
        </div>

        <!-- 新密碼 -->
        <div>
          <label class="block text-lg font-bold mb-1">新密碼：</label>
          <input
            v-model="formData.new_pwd1"
            type="text"
            class="w-full border-b-2 bg-transparent px-4 py-2 focus:outline-none focus:border-blue-600"
          />
        </div>

        <!-- 新密碼(確認) -->
        <div>
          <label class="block text-lg font-bold mb-1">新密碼(確認)：</label>
          <input
            v-model="formData.new_pwd2"
            type="text"
            class="w-full border-b-2 bg-transparent px-4 py-2 focus:outline-none focus:border-blue-600"
          />
        </div>

        <!-- 查詢按鈕 -->
        <div class="flex justify-end">
          <button
            type="submit"
            :disabled="isLoading"
            class="px-6 py-2 rounded-lg text-white shadow transition-all duration-200"
            :class="
              isLoading
                ? 'bg-gray-500 cursor-not-allowed'
                : 'bg-UbotBlue hover:brightness-110'
            "
          >
            {{ isLoading ? "變更密碼中..." : "確認" }}
          </button>
        </div>
      </div>
    </form>
  </div>
</template>

<script setup>
import { reactive, ref, onMounted } from "vue";
import { useModalStore } from "@/stores/modalStore";
import api from "@/utils/axiosInstance";
// 取得 menuStore
const modalStore = useModalStore();
const isLoading = ref(false);
const formData = reactive({
  ori_pwd: "",
  new_pwd1: "",
  new_pwd2: "",
});

// 確認密碼
const submitCheck = async () => {
  isLoading.value = true;
  const requestData = {
    data: {
      ori_pwd: formData.ori_pwd,
      new_pwd1: formData.new_pwd1,
      new_pwd2: formData.new_pwd2,
    },
  };
  const response = await api.post("S000020003", requestData);
  if (response.data.rc == "M0000") {
    formData.ori_pwd = "";
    formData.new_pwd1 = "";
    formData.new_pwd2 = "";
    modalStore.showAlert(response.data.msg, "confirm");
  } else {
    modalStore.showAlert(response.data.msg, "warning");
  }
  isLoading.value = false;
};
</script>
