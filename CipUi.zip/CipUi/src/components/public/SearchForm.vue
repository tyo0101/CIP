<template>
    <div class="max-w-2xl mx-auto bg-white p-8 rounded-lg shadow-lg">      
      <form @submit.prevent="searchFSHandler">
        <fieldset class="space-y-6">
          <!-- 目前經辦 -->
          <div>
            <label class="form-label">目前經辦：</label>
            <input type="text" v-model="formData.uid" class="input-field bg-gray-100" readonly />
          </div> 
          <!-- 選擇日期 -->
          <div>
            <label class="form-label">選擇日期：</label>
            <div class="flex flex-wrap gap-2 my-2">
              <button type="button" class="bg-UbotOrange BTN" @click="convertSearchDateTime(0)">當日</button>
              <button type="button" class="bg-UbotBlue BTN" @click="convertSearchDateTime(10)">近10日</button>
              <button type="button" class="bg-red-500 BTN" @click="convertSearchDateTime(30)">近一個月</button>
            </div>
            <div class="flex items-center gap-2">
              <input type="date" v-model="formData.searchdate_str" class="input-field" />
              <span class="text-gray-600">至</span>
              <input type="date" v-model="formData.searchdate_end" class="input-field" />
            </div>
            <p v-if="errors.searchdate" class="error-text">{{ errors.searchdate }}</p>
  
            <div class="mt-2 flex gap-4">
              <label class="flex items-center">
                <input type="radio" v-model="formData.searchdate_type" value="1" class="mr-1" /> 起案日期
              </label>
              <label class="flex items-center">
                <input type="radio" v-model="formData.searchdate_type" value="2" class="mr-1" /> 完成日期
              </label>
            </div>
          </div>
          <!-- ID -->
          <div>
            <label class="form-label">ID：</label>
            <input type="text" v-model="formData.accID" maxlength="10" class="input-field" @input="validateID" />
            <p v-if="errors.accID" class="error-text">{{ errors.accID }}</p>
          </div>  
          <!-- 提交按鈕 -->
          <div class="text-center">
            <button type="submit" class="bg-UbotBlue w-full BTN">🔍 查詢</button>
          </div>
        </fieldset>
      </form>
    </div>
  </template>
  
  <script setup>
  import { ref, reactive } from "vue";
  
  const formData = reactive({
    uid: "123456",
    searchdate_str: "",
    searchdate_end: "",
    searchdate_type: "1",
    accID: "",
  });
  
  const errors = reactive({
    searchdate: "",
    accID: "",
  });
  
  const convertSearchDateTime = (days) => {
    const today = new Date();
    const startDate = new Date();
    startDate.setDate(today.getDate() - days);
    formData.searchdate_str = startDate.toISOString().split("T")[0];
    formData.searchdate_end = today.toISOString().split("T")[0];
  };
  
  const validateID = () => {
    const regex = /^[A-Za-z0-9]+$/;
    errors.accID = formData.accID.match(regex) ? "" : "ID 只能包含英文字母與數字";
  };
  
  const searchFSHandler = () => {
    errors.searchdate = !formData.searchdate_str || !formData.searchdate_end ? "請選擇完整日期範圍" : "";
  
    if (!errors.searchdate) {
      console.log("查詢條件", formData);
      alert("查詢成功！");
    }
  };
  </script>
  
  <style scoped>
  /* 🔹 共享表單樣式 */
  .form-label {
    @apply block text-gray-700 font-semibold mb-2;
  }
  .input-field {
    @apply w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-400 focus:outline-none transition;
  }
  .error-text {
    @apply text-red-500 text-sm mt-1;
  }
  
  /* 🔹 按鈕樣式 */
  .BTN {
    @apply text-white py-2 px-4 rounded hover:brightness-110;
  }
  </style>
  