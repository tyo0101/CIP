<template>
  <div v-if="isOpen" class="fixed inset-0 bg-black bg-opacity-50 flex items-start justify-center pt-20">
      <div class="bg-white rounded-lg shadow-lg w-96 relative">
          <!-- 顏色條 -->
          <div class="h-2 rounded-t-lg" :class="{
              'bg-red-500': type === 'warning',
              'bg-UbotBlue': type === 'confirm'
          }"></div>
          <!-- 內容 -->
          <div class="p-6">
              <div class="flex justify-between items-center">
                  <h2 class="text-lg font-semibold">
                      {{ type === 'warning' ? '警告' : '確認' }}
                  </h2>
                  <button @click="closeModal" class="text-gray-400 hover:text-gray-600">&times;</button>
              </div>
              <p class="mt-2 text-gray-600">
                  {{ message }}
              </p>
              <!-- 按鈕 -->
              <div class="mt-4 flex justify-end space-x-2">
                  <button @click="closeModal" class="px-4 py-2 text-white rounded" :class="{
                      'bg-red-500 hover:bg-red-600': type === 'warning',
                      'bg-blue-500 hover:bg-UbotBlue': type === 'confirm'
                  }">
                      確認
                  </button>
              </div>
          </div>
      </div>
  </div>
</template>

<script setup>
defineProps({
  isOpen: Boolean,
  type: String, // 'warning' 或 'confirm'
  message: String
});
const emit = defineEmits(["close", "confirm"]);

const closeModal = () => emit("close");
const confirmAction = () => emit("confirm");
</script>