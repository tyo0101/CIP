<template>
  <div v-if="isOpen" class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
    <div class="relative p-6 rounded-lg flex flex-col items-center">
      <!-- 月亮形狀 -->
      <div class="absolute w-32 h-32 bg-gradient-to-r from-yellow-400 via-yellow-300 to-yellow-200 rounded-full animate-pulse moon-shape z-10"></div>
      <!-- 圖片 -->
      <img src="@/assets/IMG/LoadIngImage.png" class="w-60 h-60 z-10 mt-8" />
      <!-- 霓虹字 -->
      <div class="z-10 text-black font-bold text-6xl neon-text animate-pulse mt-6">{{ loadingText }}</div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue';
import { useModalStore } from '@/stores/modalStore';

const modalStore = useModalStore();
const isOpen = computed(() => modalStore.loading);
const loadingText = computed(() => modalStore.loadingText);
</script>

<style>
/* 霓虹效果 */
@keyframes neon-glow {
  0% {
    text-shadow: 0 0 5px #00eaff, 0 0 10px #00eaff, 0 0 15px #00eaff;
  }
  50% {
    text-shadow: 0 0 10px #00fff2, 0 0 20px #00fff2, 0 0 30px #00fff2;
  }
  100% {
    text-shadow: 0 0 5px #00eaff, 0 0 10px #00eaff, 0 0 15px #00eaff;
  }
}

/* 彩色漸變變換，RGB 燈效 */
@keyframes hue-rotate {
  0% {
    filter: hue-rotate(0deg);
  }
  100% {
    filter: hue-rotate(360deg);
  }
}

/* 霓虹燈文字樣式 */
.neon-text {
  font-size: 2rem;
  font-weight: bold;
  color: #00eaff;
  text-transform: uppercase;
  letter-spacing: 3px;
  animation: neon-glow 1.5s infinite alternate, hue-rotate 3s infinite linear;
}

/* 閃爍月亮的動畫 */
@keyframes moon-glow {
  0% {
    opacity: 0.6;
  }
  50% {
    opacity: 1;
  }
  100% {
    opacity: 0.6;
  }
}

/* 月亮形狀 */
.moon-shape {
  animation: moon-glow 3s infinite alternate;
  box-shadow: 0 0 30px 10px rgba(255, 255, 0, 0.8);
}

/* 動態圓環加載效果 */
@keyframes ring-dots {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

.circle-ring {
  position: absolute;
  width: 400px; /* 增大圓環 */
  height: 400px;
  border-radius: 50%;
  border: 5px dotted #00eaff;
  animation: ring-dots 2s infinite linear;
  border-color: #9ca3af;
  box-sizing: border-box;
  z-index: 1;
  display: flex;
  align-items: center;
  justify-content: center;
}

/* 追逐點點動畫 */
@keyframes dot-chase {
  0% {
    transform: translate(0);
  }
  25% {
    transform: translate(25px, 0);
  }
  50% {
    transform: translate(0, 25px);
  }
  75% {
    transform: translate(-25px, 0);
  }
  100% {
    transform: translate(0, -25px);
  }
}

/* 調整月亮、圖片和文字與圓環的距離 */
.moon-shape {
  top: 10px; /* 距離圓環上方的距離 */
}

img {
  margin-top: 20px; /* 圖片與圓環的距離 */
}

.neon-text {
  margin-top: 20px; /* 霓虹字與圓環的距離 */
}
</style>
