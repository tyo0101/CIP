<template>
  <div
    v-if="isOpen"
    class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-30 backdrop-blur-lg z-50"
  >
    <div class="bg-gradient-to-br from-black to-gray-900 p-6 rounded-2xl shadow-2xl max-w-sm w-full">
      <h3 class="text-lg font-semibold text-gray-100 mb-4 text-center">
        {{ message }}
      </h3>
      <div class="flex justify-end space-x-4">
        <button @click="$emit('cancel')" class="px-4 py-2 bg-gray-800 text-gray-300 rounded-lg hover:bg-gray-700">取消</button>
        <button @click="$emit('confirm')" class="px-4 py-2 bg-cyan-500 text-white rounded-lg hover:bg-cyan-400">確定</button>
      </div>
    </div>
  </div>
</template>

<script setup>
const props = defineProps({
  isOpen: Boolean,
  message: String
});
const emit = defineEmits(["confirm", "cancel"]);
</script>
