<template>
  <div class="container max-w-screen-lg mx-auto p-2">
    <div class="flex justify-end">
      <div class="max-w-max inline-flex items-center text-orange-600 text-sm px-1 py-2">
        <a href="#"
          class="flex items-center gap-1 px-3 py-1 rounded-full hover:bg-orange-100 hover:text-orange-700 transition-all">
          <svg class="w-4 h-4 text-orange-500" fill="currentColor" viewBox="0 0 20 20">
            <path d="M10 2L2 10h3v6h10v-6h3L10 2z"></path>
          </svg>
          <span>首頁</span>
        </a>
        <svg class="w-5 h-5 text-orange-400 mx-2" fill="none" stroke="currentColor" stroke-width="2"
          viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"></path>
        </svg>
        <span class="px-3 py-1 rounded-full text-orange-700 font-medium">{{
          upperPage
        }}</span>
        <svg class="w-5 h-5 text-orange-400 mx-2" fill="none" stroke="currentColor" stroke-width="2"
          viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"></path>
        </svg>
        <span class="px-3 py-1 rounded-full bg-orange-200 text-orange-900 font-semibold">{{ thisPage }}</span>
      </div>
    </div>
  </div>
</template>

<script setup>
import { useRoute } from "vue-router";
import { useMenuStore } from "@/stores/Home/menuStore";
const route = useRoute();
const menuStore = useMenuStore();
const path = route.path;

let upperPage = "";
let thisPage = "";
menuStore.menuItems.forEach((menu) => {
  if (menu.submenu) {
    menu.submenu.forEach((sub) => {
      if (sub.path == path) {
        upperPage = menu.name; // 上層目錄
        thisPage = sub.name; // 當前頁面
      }
    });
  }
});

</script>
