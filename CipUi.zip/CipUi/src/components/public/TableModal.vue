<template>
  <div class="max-w-4xl mx-auto p-2 rounded-lg">
    <DataTable :value="items" paginator :rows="10" stripedRows responsiveLayout="scroll">
      <Column v-for="col in columns" :key="col.field" :field="col.field" :header="col.header" sortable filter>
        <template v-if="col.slot" #body="slotProps">
          <slot :name="col.slot" v-bind="slotProps" />
        </template>
      </Column>
    </DataTable>
  </div>
</template>

<script setup>
import DataTable from 'primevue/datatable';
import Column from 'primevue/column';

// 接收 items (資料) 和 columns (欄位設定)
defineProps({
  items: Array, // 通用資料
  columns: Array, // 欄位設定
});

</script>
