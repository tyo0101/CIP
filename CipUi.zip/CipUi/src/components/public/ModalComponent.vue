<template>
  <Teleport to="body">
    <div
      v-if="show"
      class="fixed inset-0 flex items-center justify-center bg-black/50 backdrop-blur-sm"
      @mousedown="onMouseDown"
      @mouseup="onMouseUp"
    >
      <div
        class="bg-white p-6 rounded-lg shadow-lg w-[90%] max-w-md relative animate-fadeIn"
        @click.stop
      >
        <!-- 關閉按鈕 -->
        <button
          class="absolute top-3 right-4 text-gray-500 hover:text-gray-700"
          @click="emit('close')"
        >
          ✕
        </button>

        <!-- 插槽 -->
        <slot></slot>
      </div>
    </div>
  </Teleport>
</template>

<script setup>
const props = defineProps({
  show: Boolean,
});

const emit = defineEmits(["close"]);

let isMouseDownInside = false;

const onMouseDown = (event) => {
  // 檢查滑鼠按下時是否在 Modal 內部
  isMouseDownInside = event.target.closest("div.bg-white") !== null;
};

const onMouseUp = (event) => {
  // 如果滑鼠按下時是在 Modal 內部，則不關閉 Modal
  if (!isMouseDownInside && event.target.closest("div.bg-white") === null) {
    emit("close");
  }
};
</script>
