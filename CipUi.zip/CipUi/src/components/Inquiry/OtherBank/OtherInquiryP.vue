<template class="container">
    <div class="max-w-4xl mx-auto p-10 bg-gray-200 bg-opacity-50 shadow-lg rounded-lg">
        <h1 class="text-2xl font-bold mb-6 text-center">
            申請照會方式
        </h1>
        <form>
            <!-- 照會方式 -->
            <div class="border p-3">
                <div class="grid grid-cols-1">
                    <h4 class="text-xl font-bold mb-6">申請照會單位</h4>
                    <div class="gap-x-6 gap-y-6 mx-6">
                        <div v-for="(row, index) in otherbankDatas" :key="index"
                            class="flex flex-wrap items-center mb-6">
                            <template v-for="(item, i) in row" :key="i">
                                <label v-if="item.type === 'label'" class="whitespace-nowrap">
                                    {{ item.text }}
                                </label>
                                <input v-else-if="item.type === 'input'" type="text" v-model="otherbankForm[item.model]"
                                    :placeholder="item.placeholder || ''"
                                    class="border-b-2 bg-transparent focus:outline-none focus:border-blue-600 w-32 text-center"
                                    :disabled="item.disabled" />
                                <!-- checkbox -->
                                <label v-else-if="item.type === 'checkbox'" class="whitespace-nowrap mr-4">
                                    <input type="checkbox"
                                        v-model="otherbankForm[item.model]" :placeholder="item.placeholder || ''"
                                        class="border-b-2 bg-transparent focus:outline-none focus:border-blue-600"
                                        :disabled="item.disabled" />
                                    {{ item.text }}
                                </label>
                                <!-- select -->
                                <label v-else-if="item.type === 'select'" class="whitespace-nowrap mr-4">
                                    <select
                                        v-model="otherbankForm[item.model]" :placeholder="item.placeholder || ''"
                                        class="border-b-2 bg-transparent focus:outline-none focus:border-blue-600"
                                        :disabled="item.disabled" />
                                    {{ item.text }}
                                </label>
                            </template>
                        </div>
                    </div>
                </div>
            </div>
            <InquiryForm :inquiry-fields="fields" :model-data="inquiryApply" :check-data="applyCheck"
                :show-checkbox="true" />
        </form>
    </div>
</template>

<script setup>
import { ref, reactive } from 'vue';
import InquiryForm from '@/components/Inquiry/InquiryForm.vue';
const otherbankForm = reactive({
    bankName: '',
    branch: ''
})

const otherbankDatas = [
    [
        { type: 'label', text: '（銀行代碼ex.012）銀行' },
        { type: 'input', model: 'account_bank' },
        { type: 'label', text: '分行（單位）' }
    ],
    [
        { type: 'label', text: '聯絡人：' },
        { type: 'input', model: 'cuser' },
        { type: 'label', text: '聯絡方式：' },
        { type: 'input', model: 'cuser_phone' },
        { type: 'label', text: '職稱：' },
        { type: 'input', model: 'cuser_job_title' }
    ],
    [
        { type: 'label', text: '回復方式：' },
        { type: 'checkbox', model: 'replyEmail', text: 'E-MAIL' },
        { type: 'checkbox', model: 'replyFax', text: '傳真' },
        { type: 'checkbox', model: 'replyPhone', text: '電話' },
        { type: 'input', model: 'phoneNumber' },
    ],
    [
        { type: 'label', text: '異常帳戶、信用卡認定標準：' },
        { type: 'select', model: 'account_bank' },
    ],
    [
        { type: 'label', text: '身份證明文件號碼(非必填)：' },
        { type: 'input', model: 'account_bank' },
    ],
    [
        { type: 'label', text: '照會金融帳號/信用卡：' },
        { type: 'input', model: 'account_bank' },
    ],
]
const fields = [
    { label: "戶名：", inputModel: "apply_accountName" },
    { label: "開戶日期：", inputModel: "apply_accountOpenDate" },
    { label: "年齡：", inputModel: "apply_age" },
    { label: "職業類別：", inputModel: "apply_job" },
    { label: "開戶目的：", inputModel: "apply_accountStatus" },
    { label: "帳戶戶況：", inputModel: "apply_purpose" },
    { label: "姓名：", inputModel: "apply_gender" },
    { label: "國籍：", inputModel: "apply_nationality" },
    { label: "其他：", inputModel: "apply_other", placeholder: "經辦手動填寫", disabled: false },
]
const inquiryApply = reactive({
    apply_accountName: "",
    apply_accountOpenDate: "",
    apply_age: "",
    apply_job: "",
    apply_accountStatus: "",
    apply_purpose: "",
    apply_gender: "",
    apply_nationality: "",
    apply_other: "",
    apply_other_content: "",
})
const applyCheck = reactive({
    apply_accountName: false,
    apply_accountOpenDate: false,
    apply_age: false,
    apply_job: false,
    apply_accountStatus: false,
    apply_purpose: false,
    apply_gender: false,
    apply_nationality: false,
    apply_other: false,
});
</script>