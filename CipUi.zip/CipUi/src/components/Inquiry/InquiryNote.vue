<template class="container">
  <div class="max-w-4xl mx-auto p-10 bg-gray-200 bg-opacity-50  shadow-lg rounded-lg">
    <h1 class="text-2xl font-bold mb-6 text-center">
      聯邦商業銀行存款帳戶/信用卡照會申請書
    </h1>

    <form @submit.prevent="submitForm">
      <!-- 基本資訊 -->
      <div class="grid grid-cols-2 gap-5">
        <div class="text-lg font-bold">申請日期:<span></span></div>
        <div class="text-lg font-bold">流水編號:<span></span></div>
      </div>
      <div class="border p-3">
        <div class="grid grid-cols-1 gap-5">
          <div class="">
            <span>申請照會單位</span>
            <div class="grid grid-cols-2 gap-4 ml-6">
              <div v-for="unit in units" :key="unit.model">
                <input v-if="unit.hasCheckbox" v-model="form[unit.checkModel]" type="checkbox" class="mr-2" />
                {{ unit.labelHead }}
                <input v-model="form[unit.inputModel]" type="text"
                  class="text-center dark:border-gray-600 bg-transparent border-b-2 appearance-none focus:outline-none focus:border-blue-600"
                  :placeholder="unit.placeholder" />
                {{ unit.labelFoot }}
              </div>
            </div>
          </div>

          <div>
            <span>身分證明文件號碼(非必填)</span>
            <div>
              <input
                class="dark:border-gray-600 bg-transparent border-b-2 appearance-none focus:outline-none focus:border-blue-600"
                placeholder="" />
            </div>
          </div>

          <div>
            <div>照會金融帳號</div>
            <div>
              <input
                class="dark:border-gray-600 bg-transparent border-b-2 appearance-none focus:outline-none focus:border-blue-600"
                placeholder="" />銀行<input
                class="dark:border-gray-600 bg-transparent border-b-2 appearance-none focus:outline-none focus:border-blue-600"
                placeholder="" />分行&nbsp;帳號<input
                class="dark:border-gray-600 bg-transparent border-b-2 appearance-none focus:outline-none focus:border-blue-600"
                placeholder="" />
            </div>
          </div>
          <div>
            <div class="grid grid-cols-2 gap-4">
              <div class="grid grid-cols-1">
                <span class="">照會信用卡:發卡機構(非必填)</span>
                <input
                  class="dark:border-gray-600 bg-transparent border-b-2 appearance-none focus:outline-none focus:border-blue-600"
                  placeholder="" />
              </div>

              <div>
                <div class="grid grid-cols-1">
                  <span class="">卡號</span>
                  <div>
                    <input v-model="cardNumber" @input="formatInput"
                      class="dark:border-gray-600 bg-transparent border-b-2 appearance-none focus:outline-none focus:border-blue-600" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!--擬照會項目開始-->
        <div class="grid grid-cols-2 gap-2 mt-3">
          <div class="col-span-2 text-center">擬照會項目</div>
          <div class="col-span-2" v-for="bankCheck in bankCheckFields" :key="bankCheck.model">
            <input v-model="form[bankCheck.model]" type="checkbox" class="mr-2" />
            {{ bankCheck.label }}
            <input v-if="bankCheck.hasInput" v-model="form[bankCheck.inputModel]"
              class="dark:border-gray-600 bg-transparent border-b-2 appearance-none focus:outline-none focus:border-blue-600" />
          </div>
        </div>
        <!--擬照會項目結束-->

        <!--最下排開始 -->
        <div class="mt-4 flex justify-end">
          <button type="submit" :disabled="isLoading"
            class="bg-blue-500 text-white px-6 py-2 rounded-md hover:bg-blue-700" :class="isLoading
                ? 'bg-gray-600 hover:bg-gray-600 cursor-not-allowed'
                : 'bg-blue-500 text-white px-6 py-2 rounded-md hover:bg-blue-700'
              ">
            {{ isLoading ? "處理中..." : "提交申請" }}
          </button>
          <LoadingModal ref="loadingModal"></LoadingModal>
          <!-- API 執行結果的通知 -->
          <AlertModal v-if="showAlert" :message="alertMessage" :type="alertType" @close="showAlert = false" />
        </div>
        <!--最下排結束 -->
      </div>
    </form>

    <div class="bg-blue-500">
      <button @click="showConfirm">Confirm按鈕測試</button>
      <ConfirmModal v-if="showConfirmDialog" :message="confirmMessage" :onConfirm="confirmAction"
        :onCancel="cancelAction" />
    </div>
  </div>
</template>
<script setup>
import { reactive } from "vue";
import { ref } from "vue";
import axios from "axios";

const form = reactive({
  //  units: {},

  ownBankBranchCheckBox: "", //本行分行名稱checkbox
  ownBankBranch: "", //本行分行名稱
  ownBankCenter: "", //本行中心
  otherBankNameCheckBox: "", //他行銀行名稱checkbox
  otherBankName: "", //他行銀行名稱
  otherBankBranch: "", //他行分行(單位)
  contactPerson: "", //聯絡人
  contactInfo: "", //聯絡方式
  idNumber: "", //身分證
  bankName: "", //照會金融帳號銀行名稱
  branchName: "", //照會金融帳號分行名稱
  accountNumber: "", //照會金融帳號
  cardIssuer: "", //發卡機構
  cardNumber: "", //卡號

  //以下為擬照會項目
  bankCheckName: "", //戶名
  bankCheckDate: "", //開戶日期
  bankCheckAge: "", //年齡
  bankCheckJob: "", //職業類別
  bankCheckAccPurpose: "", //開戶目的
  bankCheckTradePurpose: "", //交易目的
  bankCheckDepositAbnormal: "", //存款異常
  bankCheckOther: "", //其他
  bankCheckOtherInput: "", //其他Input
});

const bankCheckFields = [
  { label: "戶名", model: "bankCheckName", hasInput: false, inputModel: "" },
  {
    label: "開戶/開卡日期",
    model: "bankCheckDate",
    hasInput: false,
    inputModel: "",
  },
  { label: "年齡", model: "bankCheckAge", hasInput: false, inputModel: "" },
  { label: "職業類別", model: "bankCheckJob", hasInput: false, inputModel: "" },
  {
    label: "開戶目的",
    model: "bankCheckAccPurpose",
    hasInput: false,
    inputModel: "",
  },
  {
    label: "交易目的",
    model: "bankCheckTradePurpose",
    hasInput: false,
    inputModel: "",
  },
  {
    label: "存款帳戶/信用卡之交易是否有異常情形及監控",
    model: "bankCheckDepositAbnormal",
    hasInput: false,
    inputModel: "",
  },
  {
    label: "其他",
    model: "bankCheckOther",
    hasInput: true,
    inputModel: "bankCheckOtherInput",
  },
];

const units = [
  {
    labelHead: "本行",
    checkModel: "ownBankBranchCheckBox",
    hasCheckbox: true,
    inputModel: "ownBankBranch",
    placeholder: "分行名稱",
    labelFoot: "分行",
  },
  {
    labelHead: "",
    checkModel: "",
    hasCheckbox: false,
    inputModel: "ownBankCenter",
    placeholder: "",
    labelFoot: "中心/部(處)",
  },
  {
    labelHead: "他行",
    checkModel: "otherBankNameCheckBox",
    hasCheckbox: true,
    inputModel: "otherBankName",
    placeholder: "銀行名稱",
    labelFoot: "銀行",
  },
  {
    labelHead: "",
    checkModel: "",
    hasCheckbox: false,
    inputModel: "otherBankBranch",
    placeholder: "",
    labelFoot: "分行(單位)",
  },
  {
    labelHead: "聯絡人",
    checkModel: "",
    hasCheckbox: false,
    inputModel: "contactPerson",
    placeholder: "",
    labelFoot: "",
  },
  {
    labelHead: "聯絡方式",
    checkModel: "",
    hasCheckbox: false,
    inputModel: "contactInfo",
    placeholder: "",
    labelFoot: "",
  },
];

const cardNumber = ref("");
const formatInput = (event) => {
  let rawValue = cardNumber.value.replace(/\D/g, "").slice(0, 16); //只保留數字，最多 16 位
  let formattedValue = rawValue
    .replace(/(\d{4})(?=\d)/g, "$1-") // 每 4 位數後加 "-"
    .slice(0, 19); // 確保總長度不超過 19（16數字 + 3個"-"）

  // let cursorPosition = event.target.selectionStart;
  cardNumber.value = formattedValue;

  //設定光標位置不亂跳
  setTimeout(() => {
    event.target.selectionStart = event.target.selectionEnd =
      cardNumber.value.length;
  }, 0);
};


/** 提交按鈕 */
const loadingModal = ref(null);
const isLoading = ref(false); //控制按鈕與Loading狀態
const showAlert = ref(false);
const alertMessage = ref("");
const alertType = ref("info");
const submitForm = async () => {
  isLoading.value = true; //禁用按鈕
  loadingModal.value.openLoading("測試文字"); //loadingModal開啟
  try {
    // 測試 API
    const response = await axios.get(
      "https://jsonplaceholder.typicode.com/todos/1"
    );
    // 設定alert成功通知
    alertMessage.value = "資料獲取成功！";
    alertType.value = "info";

    isLoading.value = false; //禁用按鈕
    loadingModal.value.closeLoading(); //loadingModal關閉
  } catch (error) {
    // 設定失敗通知
    alertMessage.value = "API 請求失敗，請稍後再試！";
    alertType.value = "error";

    isLoading.value = false; //禁用按鈕
    loadingModal.value.closeLoading(); //loadingModal關閉
  }
  // finally {
  //   isLoading.value = false; //禁用按鈕
  //   loadingModal.value.closeLoading();
  // }

  console.log("表單提交內容:", form);
  // 顯示Alert框
  showAlert.value = true;
  //loadingModal.value.closeLoading();
};


/** confirm測試 */
const showConfirmDialog = ref(false);
const confirmMessage = ref("");
const showConfirm = () => {
  confirmMessage.value = "自己打問句?";
  showConfirmDialog.value = true;
};
const confirmAction = () => {
  //alert
  alertMessage.value = "確定！";
  alertType.value = "info";
  showAlert.value = true;
  showConfirmDialog.value = false;
};
const cancelAction = () => {
  //alert
  alertMessage.value = "取消！";
  alertType.value = "info";
  showAlert.value = true;
  showConfirmDialog.value = false;
};
</script>
