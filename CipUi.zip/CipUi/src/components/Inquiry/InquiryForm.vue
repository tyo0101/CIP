<template>
  <div class="border p-3">
    <div class="grid grid-cols-1 gap-5">
      <div>
        <h4 class="text-xl font-bold mb-6">照會結果</h4>
        <div class="grid grid-cols-2 gap-x-6 gap-y-6 mx-6">
          <div v-for="field in inquiryFields" :key="field.inputModel">
            <label class="flex items-center">
              <template v-if="showCheckbox">
                <input
                  v-model="checkData[field.inputModel]"
                  type="checkbox"
                  class="mr-2"
                />
              </template>
              {{ field.label }}
            </label>
            <input
              v-model="modelData[field.inputModel]"
              type="text"
              class="text-center w-full dark:border-gray-600 bg-transparent border-b-2 appearance-none focus:outline-none focus:border-blue-600"
              :placeholder="field.placeholder || ''"
              :disabled="field.disabled !==false"
            />
          </div>
        </div>
      </div>
    </div>
    <div class="mt-6">
      <slot />
    </div>
  </div>
</template>
  
  <script setup>  
  const props = defineProps({
    inquiryFields: {
      type: Array,
      required: true,
    },
    modelData: {
      type: Object,
      required: true,
    },
    checkData: {
      type: Object,
      default: () => ({}),
    },
    showCheckbox: {
      type: Boolean,
      default: true,
    },
  });
  </script>
  