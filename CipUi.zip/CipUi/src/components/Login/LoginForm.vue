<template>
  <div class="flex flex-col sm:flex-row items-center justify-center">
    <div class="flex-shrink-0 w-48 sm:w-96 h-auto">
      <img src="@/assets/IMG/Ubot_Sdog.png" />
    </div>
    <div class="w-full">
      <div class="mb-6">
        <h1 class="text-4xl sm:text-5xl font-bold text-center text-white mx-16">CIP照會系統</h1>
      </div>
      <div class="bg-white bg-opacity-90 p-6 sm:p-12 rounded-2xl shadow-xl max-w-lsm sm:max-w-lg w-full">
        <h2 class="text-2xl sm:text-3xl font-bold text-center text-gray-800 mb-8">用戶登入</h2>
        <form @submit.prevent="loginSubmitForm">
          <div class="mb-6">
            <label for="username" class="block text-lg font-semibold text-gray-700">帳號</label>
            <input type="text" id="username"
              class="w-full p-4 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
              placeholder="請輸入帳號" v-model="form.uid" required />
          </div>

          <div class="mb-4">
            <label for="password" class="block text-lg font-semibold text-gray-700">密碼</label>
            <input type="password" id="password"
              class="w-full p-4 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
              placeholder="請輸入密碼" v-model="form.pass" required />
          </div>
          <button :disabled="isLoading" type="submit"
            class="bg-UbotBlue text-white w-full py-4 rounded-lg font-semibold hover:bg-blue-600 transition">
            登入
          </button>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive } from "vue";
import { useRouter } from "vue-router";
import axios from "axios";
import { useMenuStore } from "@/stores/Home/menuStore"; // 引入 Pinia Store
import { useModalStore } from "@/stores/modalStore";
const router = useRouter();
const isLoading = ref(false); //控制按鈕與Loading狀態
const form = reactive({
  uid: "",
  pass: "",
});
const menuStore = useMenuStore();

const loginSubmitForm = async () => {
  isLoading.value = true; //禁用按鈕
  useModalStore().openLoading("登入中..");
  const response = await axios.post("http://172.16.46.197/CIP/res/S000010001", {
    uid: form.uid,
    pass: form.pass,
  });
  if (["M0102", "M0101", "M0104", "M0103"].includes(response.data.rc)) {
    // 設定 Token
    document.cookie = `hexToken=${response.data.token}; path=/;`;
    // **將 funclist 存入 Pinia**
    menuStore.setMenu(response.data.result.funclist);
    // **將使用者資訊存入 Pinia**
    menuStore.setUserData({
      uid: response.data.result.uid,
      token: response.data.token,
    });
    // **跑馬燈存入 Pinia**
    menuStore.updateMarqueeText(response.data.result.Carousel[0].text);
    useModalStore().showAlert(response.data.msg, "confirm");
    useModalStore().closeLoading();
    router.push("/Home");
  } else {
    useModalStore().closeLoading();
    useModalStore().showAlert(response.data.msg, "warning");
  }
  isLoading.value = false; //啟用按鈕
};
</script>
