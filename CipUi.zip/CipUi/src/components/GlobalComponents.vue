<script>
import { defineComponent } from 'vue';
import AlertModal from "@/components/public/AlertModal.vue";
import LoadingModal from "@/components/public/LoadingModal.vue";
import ConfirmModal from "@/components/public/ConfirmModal.vue";
import ModalComponent from "@/components/public/ModalComponent.vue";
import Breadcrumb from "@/components/Public/Breadcrumb.vue";

export default defineComponent({
  install(app) {
    // 在此處全局註冊組件
    app.component('AlertModal', AlertModal);
    app.component('LoadingModal', LoadingModal);
    app.component('ConfirmModal', ConfirmModal);
    app.component('ModalComponent', ModalComponent);
    app.component('Breadcrumb', Breadcrumb);
  },
});
</script>
