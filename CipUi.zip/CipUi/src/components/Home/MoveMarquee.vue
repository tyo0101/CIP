<template>
  <div class="relative w-full flex justify-center py-5">
    <img src="@/assets/IMG/Ubot_Logo.png" class="mt-0" />
    <svg width="60" height="45" viewBox="0 0 30 24">
      <path
        fill="#d99e4a"
        d="M16 13v-2h4v2zm1.2 7L14 17.6l1.2-1.6l3.2 2.4zm-2-12L14 6.4L17.2 4l1.2 1.6zM3 15V9h4l5-5v16l-5-5z"
      />
    </svg>
    <!-- 半透明圓角膠囊背景 -->
    <div
      class="relative w-[90%] max-w-4xl overflow-hidden rounded-full bg-gradient-to-r from-white to-orange-100 shadow-inner backdrop-blur-md border border-orange-200"
    >
      <!-- 柔和光暈 -->
      <div
        class="absolute inset-0 bg-gradient-to-r from-orange-300 via-orange-200 to-yellow-200 opacity-40 blur-2xl"
      ></div>
      <!-- 跑馬燈內容 -->
      <div class="marquee">
          <div class="marquee-content">
            <span class="marquee-text text-UbotOrange">
              {{ menuStore.marqueeText }}
            </span>
          </div>
        </div>
    </div>
  </div>
</template>

<script setup>
import { reactive, ref, onMounted, computed } from "vue";
import { useMenuStore } from "@/stores/Home/menuStore";
const menuStore = useMenuStore();
// 計算跑馬燈動畫時間（讓滾動速度與字數成比例）
const marqueeDuration = computed(() => {
  return Math.max((menuStore.marqueeText.length / 5) * 1.5, 15) + "s";
});

// 根據字數計算跑馬燈內容的寬度，確保長文字不會過早循環
const marqueeWidth = computed(() => {
  return `${menuStore.marqueeText.length * 2 * 10}px`;
});
</script>
<style scoped>
/* 定義跑馬燈動畫 */
@keyframes marquee {
  from {
    transform: translateX(25%);
  }

  to {
    transform: translateX(-100%);
  }
}

.marquee {
  display: flex;
  white-space: nowrap;
  overflow: hidden;
}

.marquee-content {
  display: flex;
  min-width: v-bind(marqueeWidth); /* 讓寬度隨字數與字體大小變化 */
  animation: marquee v-bind(marqueeDuration) linear infinite;
}

.marquee-text {
  font-size: 2rem; /* 調整字體大小 */
  font-weight: bold;
}
</style>
