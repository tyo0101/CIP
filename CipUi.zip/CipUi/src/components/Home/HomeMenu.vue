<template>
  <div class="p-4 max-w-screen-lg mx-auto">
    <MoveMarquee/>
    <div class="bg-UbotOrange p-2 max-w-screen-lg mx-auto flex items-center justify-between relative">
      <!-- 漢堡按鈕（小螢幕時可見） -->
      <button @click="toggleMenu" class="lg:hidden text-white text-2xl focus:outline-none">
        ☰
      </button>
      <!-- 導覽列 -->
       <div class="flex-1 flex justify-center">
      <nav :class="[
        'lg:flex lg:space-x-6 space-y-4 lg:space-y-0 lg:static top-16 left-0 w-4/5 bg-UbotOrange lg:w-auto lg:bg-transparent p-4 lg:p-0',
        isMenuOpen ? 'block' : 'hidden',
        isMenuOpen ? 'w-full' : ''
      ]">
        <ul class="flex flex-col lg:flex-row space-y-4 lg:space-y-0 lg:space-x-6">
          <li class="relative group">
            <router-link to="/Home"
              class="text-white text-lg px-4 py-2 rounded-lg transition duration-300 hover:text-yellow-200 pb-4 font-bold">
              首頁</router-link>
          </li>
          <li v-for="(item, index) in menuItems" :key="item.name" class="relative group">
            <router-link v-if="item.path" :to="withTimestamp(item.path)"
              class="text-white text-lg px-4 py-2 rounded-lg transition duration-300 hover:text-yellow-200 pb-4 font-bold">
              {{ item.name }}
            </router-link>
            <span v-else
              class="text-white text-lg px-4 py-2 rounded-lg transition duration-300 hover:text-yellow-200 pb-4 font-bold">
              {{ item.name }}
            </span>
            <!-- 小螢幕的展開按鈕 -->
            <button v-if="item.submenu" @click="toggleSubmenu(index)" class="lg:hidden text-white text-lg ml-2">
              {{ submenuOpen[index] ? '▲' : '▼' }}
            </button>
            <div class="absolute left-0 w-full h-4 invisible group-hover:visible"></div>
            <!-- 小螢幕的子選單 -->
            <ul v-if="item.submenu"
              :class="['lg:hidden bg-gray-100 shadow-lg rounded-lg p-2 w-full', submenuOpen[index] ? 'block' : 'hidden']">
              <li v-for="subItem in item.submenu" :key="subItem.name">
                <router-link :to="withTimestamp(subItem.path)"
                  class="block text-black text-lg px-4 py-2 rounded-lg hover:text-gray-600">
                  {{ subItem.name }}
                </router-link>
              </li>
            </ul>
            <!-- 大螢幕下的下拉式選單 -->
            <ul v-if="item.submenu"
              class="absolute left-0 left-1/2 -translate-x-1/2 top-11 hidden lg:group-hover:block bg-gray-100 shadow-lg rounded-lg p-2 w-56 z-50">
              <li v-for="subItem in item.submenu" :key="subItem.name" class="flex">
                <router-link :to="withTimestamp(subItem.path)"
                  class="block w-full text-left text-black text-lg px-4 py-2 rounded-lg hover:text-gray-600">
                  {{ subItem.name }}
                </router-link>
              </li>
            </ul>
          </li>
        </ul>
      </nav>
    </div>
      <!-- 登出按鈕 -->
      <button @click="logout" class="text-UbotOrange font-semibold bg-white px-4 py-2 rounded-xl text-lg hidden lg:block transition-all duration-300 shadow-md border border-UbotOrange
         hover:brightness-110 hover:scale-125">
        登出
      </button>
      </div>
  </div>
</template>
<script setup>
import { ref } from 'vue';
import { computed } from "vue";
import { useMenuStore } from "@/stores/Home/menuStore";
import MoveMarquee from '@/components/Home/MoveMarquee.vue';

const menuStore = useMenuStore();
const menuItems = computed(() => menuStore.menuItems);
const isMenuOpen = ref(false);
// 使用 ref 數組來追蹤每個子選單的開啟狀態
const submenuOpen = ref({});

// 切換漢堡選單
const toggleMenu = () => {
  isMenuOpen.value = !isMenuOpen.value;
};

// 切換子選單
const toggleSubmenu = (index) => {
  if (submenuOpen.value[index]) {
    submenuOpen.value[index] = false;
  } else {
    Object.keys(submenuOpen.value).forEach(key => {
      submenuOpen.value[key] = false;
    });
    submenuOpen.value[index] = true;
  }
};

//登出按鈕
const logout=()=>{
  menuStore.clearUserData();
  window.location.href='/';//登出後回登入頁面
}
function withTimestamp(path) {
  return {
    path,
    query: {
      t: Date.now()
    }
  }
}
</script>