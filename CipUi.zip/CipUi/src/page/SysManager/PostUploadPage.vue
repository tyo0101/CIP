<template class="container mx-auto">
  <HomeMenu />
  <div :class="{ 'mt-40': isMenuOpen }"></div>
  <!-- 頁籤 -->
  <Breadcrumb/>
  <PostUpload />
</template>
<script setup>
import { ref } from "vue";
import HomeMenu from "@/components/Home/HomeMenu.vue";
import PostUpload from "@/components/SysManager/PostUpload.vue";
const isMenuOpen = ref(false);
</script>
