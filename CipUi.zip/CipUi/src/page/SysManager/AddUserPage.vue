<template class="container mx-auto">
  <HomeMenu />
  <div :class="{ 'mt-40': isMenuOpen }"></div>
  <Breadcrumb/>
  <AddUser/>
</template>

<script setup>
import { ref } from 'vue';
import HomeMenu from '@/components/Home/HomeMenu.vue';
import AddUser from '@/components/SysManager/AddUser.vue';

const isMenuOpen = ref(false); // 控制側邊欄
</script>
