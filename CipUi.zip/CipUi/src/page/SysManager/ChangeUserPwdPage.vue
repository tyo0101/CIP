<template class="container mx-auto">
  <HomeMenu />
  <div :class="{ 'mt-40': isMenuOpen }"></div>
  <Breadcrumb/>
  <ChangeUserPwd/>
</template>

<script setup>
import { ref } from 'vue';
import HomeMenu from '@/components/Home/HomeMenu.vue';
import ChangeUserPwd from '@/components/SysManager/ChangeUserPwd.vue';

const isMenuOpen = ref(false); // 控制側邊欄
</script>
