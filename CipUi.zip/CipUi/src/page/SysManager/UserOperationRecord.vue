<template class="container mx-auto">
  <HomeMenu />
  <div :class="{ 'mt-40': isMenuOpen }"></div>
  <Breadcrumb/>
  <UserOperationRecord/>
</template>

<script setup>
import { ref } from 'vue';
import HomeMenu from '@/components/Home/HomeMenu.vue';
import UserOperationRecord from '@/components/SysManager/UserOperationRecord.vue';

const isMenuOpen = ref(false); // 控制側邊欄
</script>
