<template>
  <div class="bg-gradient-to-bl from-gray-300 to-UbotBlue min-h-screen flex items-center justify-center flex-col">
    <LoginForm />
  </div>
</template>

<script setup>
import LoginForm from '@/components/Login/LoginForm.vue'
</script>