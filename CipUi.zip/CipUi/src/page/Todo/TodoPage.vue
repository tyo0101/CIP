<template class="container mx-auto">
    <HomeMenu />
    <div :class="{ 'mt-40': isMenuOpen }"></div>
    <TableModal />
  </template>
  <script setup>
  import { ref } from 'vue'
  import HomeMenu from '@/components/Home/HomeMenu.vue';
  import TableModal from '@/components/public/TableModal.vue';
  const isMenuOpen = ref(false);
  </script>