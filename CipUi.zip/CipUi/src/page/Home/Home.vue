<template class="container mx-auto">
  <HomeMenu />
  <div :class="{ 'mt-40': isMenuOpen }"></div>
</template>
<script setup>
import { ref } from 'vue'
import HomeMenu from '@/components/Home/HomeMenu.vue';
const isMenuOpen = ref(false);
</script>