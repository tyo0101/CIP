<template class="container mx-auto">    
    <HomeMenu />
    <div :class="{ 'mt-40': isMenuOpen }"></div>
    <!-- 頁籤 -->
  <Breadcrumb/>
    <InquiryNote />
</template>
<script setup>
import { ref } from 'vue'
import HomeMenu from '@/components/Home/HomeMenu.vue'
import InquiryNote from '@/components/Inquiry/InquiryNote.vue'
const isMenuOpen = ref(false);
</script>