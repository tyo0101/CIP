<template class="container mx-auto">
    <HomeMenu />
    <div :class="{ 'mt-40': isMenuOpen }"></div>
    <!-- 頁籤 -->
  <Breadcrumb/>
    <SearchForm />
</template>
<script setup>
import { ref } from 'vue'
import HomeMenu from '@/components/Home/HomeMenu.vue'
import SearchForm from '@/components/public/SearchForm.vue'
const isMenuOpen = ref(false);
</script>