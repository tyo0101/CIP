import {
  createWebHashHistory,
  // createWebHistory,
  createRouter,
} from "vue-router";
const history = createWebHashHistory();
import Login from '../page/Login/Login.vue'

const routes = [
  {
    path: "/",
    name: 'Login',
    component: Login,
  },
  {
    path: "/Home",
    component: () => import('@/page/Home/Home.vue')
  },
  {
    path: "/OtherInquiryPage", 
    component: () => import("@/page/Inquiry/OtherInquiryPage.vue"),
  },
  {
    path: "/InquiryNotePage", 
    component: () => import("@/page/Inquiry/InquiryNotePage.vue"),
  },
  {
    path: "/InquirySearchPage", 
    component: () => import("@/page/Inquiry/InquirySearchPage.vue"),
  },
  {
    path: "/PostUploadPage", 
    component: () => import("@/page/SysManager/PostUploadPage.vue"),
  },
  {
    path: "/TodoPage", 
    component: () => import("@/page/Todo/TodoPage.vue"),
  },
  {
    path: "/AddUserPage", 
    component: () => import("@/page/SysManager/AddUserPage.vue"),
  },
  {
    path: "/UserListPage", 
    component: () => import("@/page/SysManager/UserListPage.vue"),
  },
  {
    path: "/UserOperationRecord", 
    component: () => import("@/page/SysManager/UserOperationRecord.vue"),
  },
  {
    path: "/ChangeUserPwd", 
    component: () => import("@/page/SysManager/ChangeUserPwdPage.vue"),
  },
];
const router = createRouter({
  history,
  routes,
});

export default router;
