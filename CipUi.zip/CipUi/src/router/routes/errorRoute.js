const errorRoute = [
  {
    path: "/:catchAll(.*)",
    redirect: "/404",
  },
];
export default errorRoute;
