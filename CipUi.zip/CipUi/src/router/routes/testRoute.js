const testRoute = [
  {
    path: "/Test",
    component: () => import("@/page/test/App.vue"),
  },
  {
    path: "/About",
    component: () => import("@/page/test/About.vue"),
  },
  {
    path: "/404",
    component: () => import("@/page/test/404.vue"),
  },
  {
    path: "/Home",
    component: () => import("@/page/test/Home.vue"),
    children: [
      {
        path: "/Home/Life",
        name: "L1",
        component: () => import("@/page/test/Life.vue"),
      },
    ],
  },
  {
    path: "/Life",
    component: () => import("@/page/test/Life.vue"),
  },
  {
    path: "/StoreDemo",
    component: () => import("@/page/test/StoreDemo.vue"),
  },
  {
    path: "/Component",
    component: () => import("@/page/test/Component.vue"),
  },
];

export default testRoute;
