<template>
  <div>
    <router-view :key="$route.fullPath" />
    <LoadingModal v-if="modal.loading" />
    <AlertModal
      :isOpen="modal.alert.isOpen"
      :message="modal.alert.message"
      :type="modal.alert.type"
      @close="modal.closeAlert"
    />
    <ConfirmModal
      :isOpen="modal.confirm.isOpen"
      :message="modal.confirm.message"
      @confirm="modal.confirmOk"
      @cancel="modal.confirmCancel"
    />
  </div>
</template>
<script setup>
import { useModalStore } from "@/stores/modalStore";
import AlertModal from "@/components/Public/AlertModal.vue";
import ConfirmModal from "@/components/Public/ConfirmModal.vue";
import LoadingModal from "@/components/Public/LoadingModal.vue";
const modal = useModalStore();
</script>
<style>
html {
  overflow-y: scroll;
  scrollbar-gutter: stable;
}
</style>
